function [res] = fshift(inData,fc,FS)
%shift signal in a freq domain
%inData - input signal
%fc - carier frequency in Hz
%FS - sampling frequency in Hz
res=...;
end

